void add(int N, /*[out]*/ double *out, double *a1, double *a2);
