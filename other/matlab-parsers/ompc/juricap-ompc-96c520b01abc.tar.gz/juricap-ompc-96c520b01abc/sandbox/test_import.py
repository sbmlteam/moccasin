
import ompc

addpath('examples/mfiles')
import add

print add(1,2)
