
import ompc
addpath('mfiles')
import add
print add(1,2)
