function out = add(a, b)
% adds values of a and b
out = a+b;
