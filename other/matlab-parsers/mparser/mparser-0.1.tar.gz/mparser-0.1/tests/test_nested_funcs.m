function test_nested_funcs(x)

  a = 42;

  ;
  
  function bob(x)
    x = 42;
  end
  
end
